%Code to solve 1d linearised shallow water equation with DG method
%Analytical solution used is 
%hs = 1/2(cos(c*pi*x)*cos(c*pi*t))
%U = 1/2(sin(c*pi*x)*sin(c*pi*t))
%Initial condition used is
%hs = 1/2(cos(c*pi*x))
%U = 0
clear;
close all;
N=[4 8 18 36 52];
L=[1 2 4 6 8];
for l=1:5
for range=1:5
  
nel=N(range);                           %number of elements(Ne)
nelem=nel;
h1(range)=1/(nelem-1);

nop=L(l);                               %interpolation order/intervals(N)
noq=nop+1;        %integration order(Q)
npoin = nel*nop+1;    %number of gridpoints
np=nel*(nop+1);
ngl=nop+1;    %for loop 0.....N
nboun=2;
nside=nel;
xmu=0.05;
nq=noq + 1;   %for loop 0.....Q
%M=[0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0];
%for kk=1:10
time_final=1.0;
dt=0.00001;
ntime=time_final/dt;
Courant_max=0.25;
delta=1;
eq = 'linear';
g=1;
hb=1;


%Compute LGL Points
%[xgl,wgl]=legendre_gauss_lobatto(ngl);

%[xnq,wnq]=legendre_gauss_lobatto(nq);
%[xnq,wnq]=legendre_gauss(nq);

%Compute Lagrange Polynomial and derivatives
%[psi,dpsi] = lagrange_basis3(ngl,nq,xgl,xnq);

%Compute LGL Points
[xgl,wgl]=legendre_gauss_lobatto(ngl);

%Compute Legendre Cardinal functions and derivatives
[psi,dpsi,xnq,wnq] = lagrange_basis(ngl,nq,xgl);

%Create Grid
[coord,intma,intma_dg,bsido,iperiodic] = create_grid_1d_dg(npoin,nelem,nboun,ngl,xgl);

coord1=zeros(np,1);
ii=0;
for ie=1:nelem
    for j=1:ngl
        ii=ii+1;
        ip=intma(ie,j);
        coord1(ii,1)=coord(ip,1);
    end
end

%Extract the point x=0.5
for ii=1:np
    bb=coord1(ii,1);
    if(bb==0.5)
        countt=ii;
        
    end
end


%Compute Courant Number
%Courant = compute_Courant1(ua,intma_dg,coord1,nelem,ngl,dt);
%disp(Courant);
%cour(m)=Courant;

%Compute Metric Terms
[x_ksi,ksi_x,jac] = metrics_onedim(coord,intma,psi,dpsi,wnq,nelem,ngl,nq);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%create local mass matrix for each element
Mmatrix1=zeros(ngl,ngl,nelem);
Dmatrix=zeros(ngl,ngl,nelem);
        for ie=1:nelem
            for k=1:nq   %Q=N for inexact integration
             for jj=1:ngl
                 for ii=1:ngl
                       
                       wq=x_ksi(k,ie).*wnq(k).*psi(ii,k).*psi(jj,k);
                       Mmatrix1(ii,jj,ie)=Mmatrix1(ii,jj,ie) + wq;
                       Dmatrix(ii,jj,ie)=Dmatrix(ii,jj,ie)+wnq(k).*dpsi(ii,k).*psi(jj,k);
                 end
              end
            end
        end
 
 %create local flux matrix
 flux=zeros(ngl,ngl,nelem);
 for ie=1:nelem
     for jj=1:ngl
         for ii=1:ngl
             flux(ii,jj,ie)=flux(ii,jj,ie)+(psi(ii,nq).*psi(jj,nq)-psi(ii,1).*psi(jj,1));
         end
     end
 end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%create global mass matrix, Differentiation and Flux matrix for DG
M_DG=zeros(np,np);
Diff_DG=zeros(np,np);
Flux_DG=zeros(np,np);
 for ie=1:nelem 
    for j = 1:ngl 
       jj = intma_dg(ie,j);
        for i = 1 : ngl
           ii = intma_dg(ie,i);
              M_DG(ii,jj) = M_DG(ii,jj) + Mmatrix1(i,j,ie);
              Diff_DG(ii,jj) = Diff_DG(ii,jj)+ Dmatrix(i,j,ie);
              Flux_DG(ii,jj)=Flux_DG(ii,jj)+flux(i,j,ie);
        end
    end
 end
 
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%Modifying DG Flux matrix by using rusanov flux 
n_l=-1.0;   %normal on left side
n_r= 1.0;   %normal on right side
Flux_star_dg=zeros(np,np);
for ie = 1 : nelem   %loop over element
 left = ie-1; %identify the left element of this face
     if (ie == 1) 
       left = nelem;
     end 
     ii = intma_dg(ie,1);
     jj = intma_dg(left,ngl); 
     Flux_star_dg(ii,ii)=0.5*n_l*(1 + n_l*delta);                 %0.5*n_l(1+n_l*delta_diss);
     Flux_star_dg(ii,jj)=0.5*n_l*(1 - n_l*delta);                 %0.5*n_l(1-n_l*delta_diss);
     right=ie+1;
     if (ie == nelem)
         right=1;
     end
     ii=intma_dg(ie,ngl);
     jj=intma_dg(right,1);
     Flux_star_dg(ii,ii)=0.5*n_r*(1+n_r*delta);                      %0.5*n_r(1+n_r*delta_diss);
     Flux_star_dg(ii,jj)=0.5*n_r*(1-n_r*delta);                      %0.5*n_r(1-n_r*delta_diss);
end
%create Inverse matrices 
Diff_cap = inv(M_DG)*Diff_DG;
Flux_cap = inv(M_DG)*Flux_DG;                                        %inv(M_DG)*Diff_DG;
R_matrix=Diff_cap - Flux_cap;
  
%Compute Exact Solution

time=0;
qa=exact_solution_1d(coord1,np,time);

h = qa(:,1); u = qa(:,2)./h; hu = qa(:,2);
q_old=qa;
q_ini =qa;

for n=1:ntime
 
                 q_old(1,2)=0;       %No flux boundary condition for momentum
                 q_old(np,2)=0;
                 q_old(1,1)=0.5*cos(2*pi*time);
                 q_old(np,1)=q_old(1,1);
                 %h=q_old(:,1); u=q_old(:,2)./h; 
                 lambda_max=1;
                 
                 disp(lambda_max);
                 time = time + dt;
             
     
             
              q1 = q_old + dt*(Diff_cap*rhs_dg(q_old,np,eq)-Flux_cap*global_flux(nelem,np,q_old,ngl,intma_dg,lambda_max));
              q1(1,2)=0; q1(np,2)=0; q1(1,1)=0.5*cos(2*pi*time); q1(np,1)=q1(1,1);
              %fprintf('q1 values'); disp(q1);
              
              q2 = (3.0/4.0)*q_old + (1.0/4.0)*q1 + (1.0/4.0)*dt*(Diff_cap*rhs_dg(q1,np,eq)-Flux_cap*global_flux(nelem,np,q1,ngl,intma_dg,lambda_max));
              q2(1,2)=0; q2(np,2)=0; q2(1,1)=0.5*cos(2*pi*time); q2(np,1)=q2(1,1);
               %fprintf('q2 values'); disp(q2); 
              
              q_new = (1.0/3.0)*q_old + (2.0/3.0)*q2 + (2.0/3.0)*dt*(Diff_cap*rhs_dg(q2,np,eq)-Flux_cap*global_flux(nelem,np,q2,ngl,intma_dg,lambda_max));
             
               % fprintf('q3 values'); disp(q3);
              
              %q_new = q_old + 0.1667*dt*((Diff_cap*rhs_dg(q_old,np,eq)-Flux_cap*global_flux(nelem,np,q_old,ngl,intma_dg,lambda_max))...
                % + 2*(Diff_cap*rhs_dg(q1,np,eq)-Flux_cap*global_flux(nelem,np,q1,ngl,intma_dg,lambda_max)) + 2*...
                 %(Diff_cap*rhs_dg(q2,np,eq)-Flux_cap*global_flux(nelem,np,q2,ngl,intma_dg,lambda_max))+...
                 %(Diff_cap*rhs_dg(q3,np,eq)-Flux_cap*global_flux(nelem,np,q3,ngl,intma_dg,lambda_max)));
             
             
             
             
             
             
             
             %q_new = 0.5*q_old + 0.5*q1 + 0.5*dt*(Diff_cap*rhs_dg(q1,np)-Flux_cap*global_flux(nelem,np,q1,ngl,intma_dg));
             q_old = q_new;
             %qe=exact_solution_1d(coord1,np,time);
           
            
               
end

            q0=exact_solution_1d(coord1,np,time);
            sum_top1=0; sum_bot1=0; sum_top2=0; sum_bot2=0;
            for kk=1:np
              term_top1 = (q_new(kk,1)-q0(kk,1)).^2;
              term_bot1 = (q0(kk,1)^2);
              term_top2 = (q_new(kk,2)-q0(kk,2)).^2;
              term_bot2 =  (q0(kk,2)^2);
              sum_top1 = sum_top1 + term_top1;
              sum_bot1 = sum_bot1 + term_bot1;
              sum_top2 = sum_top2 + term_top2;
              sum_bot2 = sum_bot2 + term_bot2;
            end
            
              
            
          
            err1(l,range)=sqrt(sum_top1/np);           
           
            err2(l,range)=sqrt(sum_top2/np);
end

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for l=1:4
    L21=err1(l,:);
    L22=err2(l,:);
    for ml=1:(range-1)
    ocl21(l,ml)=log(L21(ml)/L21(ml+1))/log(h1(ml)/h1(ml+1));
    ocl22(l,ml)=log(L22(ml)/L22(ml+1))/log(h1(ml)/h1(ml+1));
    end
end




%CONVERGENCE RATE
%show(err1,err2,N,l);

%Extracting data
%hs=q_new(:,1);
%h=hs+hb;
%U=q_new(:,2);
%hs_exact=q0(:,1);
%U_exact=q0(:,2);
            figure(1)
            h= plot(coord1,q_new(:,1),'k');
            set(h,'linewidth',2);
            axis([0 1 -1 1]);
            xlabel('x values');
            ylabel('h values');
            title(sprintf('time=%1.3f',time),'fontsize',16);
           
            figure(2)
             h = plot(coord1,q_new(:,2),'b');
             set(h,'linewidth',2);
            axis([0 1 -1 1]);
            xlabel('x values');
            ylabel('U values');
            title(sprintf('time=%1.3f',time),'fontsize',16);
            
           


%plot for x=0.5
%figure(3)
%plot(t,qq);
%xlabel('time(in seconds)');
%ylabel('momentum value');
%title(sprintf('x=%1.3f',0.5),'fontsize',16);

            


 
%plot exact solution
%figure(3)
%time=0;
%for n=1:ntime
 %  qe=exact_solution_1d(coord1,np,time);
  % time = time + dt;
  % plot(coord1,qe(:,1),'--')
  % hold on
  % axis([0 1 -2 2]);
  % xlabel('x values');
  % ylabel('hs values');
   %comet(coord1,qe(:,1))
  %title(sprintf('time=%1.3f',time),'fontsize',16);
%end
%hold off;

%plot exact solution
%figure(5)
%time=0;
%for n=1:ntime
   %qe=exact_solution_1d(coord1,np,time);
   %time=time+dt;
   %plot(coord1,qe(:,2))
   %hold on
   %axis([0 1 -2 2]);
   %xlabel('x values');
   %ylabel('U values');
   %comet(coord1,qe(:,1))
   %title(sprintf('time=%1.3f',time),'fontsize',16);
%end
%hold off;


%bot = sum(hs_exact.^2);
 
   %N_p(range)=np;
fprintf('Error for Height element\n');
disp(err1);
fprintf('Error for Momentum element\n');
disp(err2);
%figure(1)
%plot convergence rate

   % end
  % semilogy(N_p,err)
   %xlabel('Np');
   %ylabel('error');
 % hold on
%end
%hold off;

%else
    %fprintf("value of courant number is not favourable");
%end













