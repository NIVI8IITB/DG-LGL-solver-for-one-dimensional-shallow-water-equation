%create global flux vector
function f_star=global_flux(nelem,np,qe,ngl,intma_dg,lambda_max)
h = qe(:,1); u =qe(:,2)./h; hu=qe(:,2);
g=9.81;
hb=1;
delta=1;  %for rusanov flux
f_star=zeros(np,2);
for e=1:nelem
    left=e;
    right=e+1;
    if (e==nelem)
        right=1;
    end
 ii=intma_dg(left,ngl);
 jj=intma_dg(right,1);

 %%%%%%%%%%%%For linear case%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %f1=0.5*(qe(ii,2)+qe(jj,2))-0.5*abs(lambda_max)*delta*(qe(jj,1)-qe(ii,1));
 %f2=0.5*g*hb*(qe(ii,1)+qe(jj,1))-0.5*abs(lambda_max)*delta*(qe(jj,2)-qe(ii,2));
%%%%%%%%%%%%%%%%%For non linear case%%%%%%%%%%%%%%%%%%%%%%%%%%
 f1 = 0.5*(hu(ii) + hu(jj)-lambda_max*delta*(h(jj)-h(ii)));  %%First row

 f2 = 0.5*(0.5*g*h(ii)*h(ii) + h(ii)*u(ii)*u(ii) + 0.5*g*h(jj)*h(jj) + h(jj)*u(jj)*u(jj)- lambda_max*delta*(hu(jj)-hu(ii)));

 f_star(ii,1)=f1;
 f_star(ii,2)=f2;
 f_star(jj,1)=f1;
 f_star(jj,2)=f2;
end

 