%Find metrics for 1D basis element 
function [x_ksi,ksi_x,jac] = metrics_onedim(coord,intma,psi,dpsi,wnq,nelem,ngl,nq)

%Initialize Global Arrays
ksi_x=zeros(nq,nelem);
jac=zeros(nq,nelem);

%Initialize Local Arrays
x_ksi=zeros(nq,1);
x=zeros(ngl);

%loop thru the elements
for ie=1:nelem
     %Store Element Variables
    for  i=1:ngl
       ip=intma(ie,i);
       x(i)=coord(ip,1);
    
    end %i  
   
    %Construct Mapping Derivatives: dx/dksi, dx/deta, dy/dksi, dy/deta
  
        for k=1:nq
           sum_ksi=0;
              for i=1:ngl
        sum_ksi=sum_ksi + dpsi(i,k).*x(i);
        
              end %i
        x_ksi(k,ie)=sum_ksi;
        end %k
    

   % [x_ksi,x_eta]=map_deriv(psi,dpsi,x,ngl,nq);
   % [y_ksi,y_eta]=map_deriv(psi,dpsi,y,ngl,nq);

    %Construct Inverse Mapping: dksi/dx, dksi/dy, deta/dx, deta/dy
    for j=1:nq
   
        xjac=x_ksi(j,ie);
        ksi_x(j,ie)=+1.0/xjac;
        
        jac(j,ie)=wnq(j)*abs(xjac);
    
    end %j
end %ie
