function qe =exact_sol( coord1,np,time )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
qe=zeros(np,2);
for ip=1:np
    x=coord1(ip,1);
    qe(ip,1)=0; %first column represents hs values
    qe(ip,2)=0;  %second column represents U values
end


