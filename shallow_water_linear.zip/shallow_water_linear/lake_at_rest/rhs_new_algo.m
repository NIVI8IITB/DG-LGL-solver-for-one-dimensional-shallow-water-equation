%create right hand side vector
function rhs=rhs_new_algo(qe,np,Flux_cap,Diff_cap,nelem,intma_dg,ngl)
rhs=zeros(np,2);
qe(1,2)=0;
qe(np,2)=0;

for i=1:np
    fstar=global_flux(nelem,np,qe,ngl,intma_dg);
    for j=1:np
        
        rhs(i,1)=Diff_cap(i,j).*qe(j,2)-Flux_cap(i,j).*fstar(j,1);
        rhs(i,2)=Diff_cap(i,j).*qe(j,1)-Flux_cap(i,j).*fstar(j,2);
    end
end
