%Program to find the courant number
function [Courant,dx,dt] = compute_Courant1(ua,intma_dg,coord1,nelem,ngl,dt)

%Initialize
Courant=-1000;
%xmin=min(coord1);
%xmax=max(coord1);
%dx=(xmax-xmin)/nelem;   % delta x

for ie=1:nelem
       
    %Loop through I points
    
    for i=1:ngl-1
        i1=intma_dg(ie,i);
        i2=intma_dg(ie,i+1);
        
        x1=coord1(i1); 
        x2=coord1(i2); 

        u1=ua(i1);
        u2=ua(i2);
        uu=(u1+u2)/2;

        dx = x2-x1;
        C=(2+uu)*dt/dx;
        Courant=max(Courant,C); 
    end %i
    
end %ie
