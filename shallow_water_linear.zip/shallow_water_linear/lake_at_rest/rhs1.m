%create right hand side vector
function rhs=rhs1(qe,np)
rhs=zeros(np,2);
qe(1,2)=0;
qe(np,2)=0;
g=1;
hb=1;

  
    for i=1:np
        rhs(i,1)=qe(i,2);
        rhs(i,2)=g*hb*qe(i,1);
    end
