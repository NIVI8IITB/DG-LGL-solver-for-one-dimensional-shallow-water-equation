%Find the exact solution
function [qe,ue] = exact_solution_1d(coord1,np,time)
%Initialize
qe=zeros(np,2);
ue=zeros(np,1);

for ip=1:np
    x=coord1(ip,1);
    qe(ip,1)=0; %first column represents hs values
    qe(ip,2)=0;  %second column represents U values
   
end


