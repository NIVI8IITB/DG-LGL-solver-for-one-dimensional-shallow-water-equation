mov = VideoWriter('demo.avi');
mov.open;

figure;
for x = 1:10
    data = rand(25,25);
    surf(data);

    renderer = get(gcf,'renderer');
    if strcmp(renderer,'painters')
        renderer = 'opengl';
    end
    frame = hardcopy(gcf, ['-d' renderer], ['-r' num2str(round(300))]);

    writeVideo(mov, frame);

end

mov.close;
mov.delete;