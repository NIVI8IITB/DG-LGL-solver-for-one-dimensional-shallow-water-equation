%To plot convergence rate
function show(err1,err2,N,l)
figure(1)
for i=1:l
    semilogy(N,err1(i,:))
    hold on
    xlabel('Grid points');
    ylabel('L2 error');
    legend;
end
hold off;
figure(2)
for i=1:l
    semilogy(N,err2(i,:))
    hold on
    xlabel('Grid points');
    ylabel('L2 error');
    legend;
end
hold off;