function f = func(coord1,np)
for i=1:np
  if((coord1(i,1)>=8)&&(coord1(i,1)<=12))
    f(i) = 0.2-0.05*(coord1(i,1)-10)^2;
  else
    f(i) = 0;
  end

end
