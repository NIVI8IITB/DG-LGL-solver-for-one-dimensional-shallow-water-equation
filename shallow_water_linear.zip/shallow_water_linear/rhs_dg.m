%create right hand side vector
function rhs=rhs_dg(qe,np,eq)
rhs=zeros(np,2);
h=qe(:,1); u = qe(:,2)./h; hu=qe(:,2);

switch eq
    case 'linear'
        
        g=1;
        hb=1;

    for i=1:np
        rhs(i,1)=hu(i);
        rhs(i,2)=g*hb*h(i);
    end

    case 'nonlinear'
        
        g=9.81;
    
        
    for i=1:np
        rhs(i,1)=hu(i);
        rhs(i,2)=0.5*g*h(i)*h(i) + h(i)*u(i)*u(i);
    end
        
    otherwise
        disp('Case not valid');
end


