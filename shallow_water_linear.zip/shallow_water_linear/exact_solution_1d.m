%Find the exact solution
function qe = exact_solution_1d(coord1,np,time)
%Initialize
qe=zeros(np,2);

c=2;

qe(1,2)=0;
qe(np,2)=0;
qe(1,1)=0.5*cos(2*pi*time);
qe(np,1)=qe(1,1);
for ip=1:np
    x=coord1(ip,1);
    qe(ip,1)=0.5*cos(c*pi*x)*cos(c*pi*time);  %first column represents hs values
    qe(ip,2)=0.5*sin(c*pi*x)*sin(c*pi*time);  %second column represents U values
    
end


